chrome.tabs.onUpdated.addListener(function(tabId, changeInfo) {
    if (!changeInfo.url) {
        return;
    }

    fetchData(changeInfo.url, function(data) {
        chrome.tabs.sendMessage(tabId, {
            url: changeInfo.url,
            message: "data",
            data
        });
    });
});

chrome.runtime.onMessage.addListener(function(request) {
    if (request.message === "fetch") {
        fetchData(request.url, function(data) {
            chrome.tabs.query({ active: true, currentWindow: true }, function(
                tabs
            ) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    url: request.url,
                    message: "data",
                    data
                });
            });
        });
    }
});

function fetchData(url, callback) {
    const regex = /github\.com\/([\w_-]+)\/([\w_-]+)\/pull\/(\d+)/g;
    var urlParts = regex.exec(url);

    if (!urlParts) {
        return;
    }

    fetch(
        `https://refdiff.brito.com.br/${urlParts[1]}/${urlParts[2]}/${
            urlParts[3]
        }?t=${+new Date()}` // TODO remove seed
    )
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            callback(data);
        });
}
